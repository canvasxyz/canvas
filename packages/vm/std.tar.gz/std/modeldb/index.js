export class ModelDB {
  constructor(init) {
    this.init = init;
  }
}
